Verilog Unsigned Multiplier-Accumulator Design Example v2.0
README File

This readme file for the Verilog Unsigned Multiplier-Accumulator
Design contains information about the design example in the
Quartus ll HDL Templates. Ensure that you have read the
information on the Verilog Unsigned Multiplier-Accumulator Design
Example web page before using the example.

This file contains the following information:

o  Package Contents
o  Software Tool Requirements
o  Release History
o  Technical Support

Package Contents
================

Verilog Unsigned Multiplier-Accumulator Design Example v2.0


Software Tool Requirements
==========================

The Quartus II software version 9.1 or later, 
or supported versions of third-party synthesis tools. 

Contact your local sales representative if you do not have the
necessary software tools.


Release History
===============

Version 1.0
-----------
- First release of example.

Version 2.0
-----------
- Updated release using Quartus ll 9.1 HDL templates


Technical Support
=================

Although we have made every effort to ensure that this design
example works correctly, there might be problems that we have not
encountered. If you have a question or problem that is not
answered by the information provided in this readme file or the
example's documentation, refer to the Altera technical support
web site: 

http://www.altera.com/mysupport

 
Last updated February, 2010                                
Copyright (c) 2010 Altera Corporation. All rights reserved.